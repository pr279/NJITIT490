#!/bin/bash

#scp the rollback package to destination


cd /home/jkm34/bundle

# $1 is filename

#delete contents first
ssh alisha@192.168.1.27 'rm -rf /home/alisha/deploy/*'

#send new rollback version
pv $1 | ssh alisha@192.168.1.27 'cat | tar xz -C /home/alisha/deploy/'
