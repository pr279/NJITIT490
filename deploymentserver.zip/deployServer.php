#!/usr/bin/php
<?php
require_once('/home/jkm34/git/Julio/path.inc');
require_once('/home/jkm34/git/Julio/get_host_info.inc');
require_once('/home/jkm34/git/Julio/rabbitMQLib.inc');
function doRollback ($type,$package,$server,$packagename,$version,$rollbackversion){
        echo "Rollback Request received" . PHP_EOL;
        echo "Type: " . $type . PHP_EOL;
        echo "Package From: " . $package . PHP_EOL;
        echo "Server: " . $server . PHP_EOL;
	echo "Package Name: " . $packagename . "-" . $rollbackversion	.  PHP_EOL;


	$mydb = new mysqli('192.168.1.12','root','password','deploy');
        if ($mydb->errno != 0){
                echo "Failed to connect to database: ".$mydb->error.PHP_EOL;
                exit(0);
        }
	#add if statement to check if true...
	#vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        $query = mysqli_query($mydb, "SELECT * Deploy WHERE VALUES('$packagename','$rollbackversion')");
	echo "Previous version found! Rolling back!" . PHP_EOL;
	#destination of the tar to send
        $file = "/home/jkm34/bundle/" . $packagename . "-" . $rollbackversion . ".tgz";
        echo "FILEPATH: " . $file . PHP_EOL;
	
	#execute script with the filepath as an aruegment
        $file = escapeshellarg($file);
         exec("./rollback.sh $file");





	
}
function doDeploy ($type,$package,$server,$packagename,$version){
	echo "Deployment Request received" . PHP_EOL;
        echo "Type: " . $type . PHP_EOL;
        echo "Package From: " . $package . PHP_EOL;
        echo "Server: " . $server . PHP_EOL;
        echo "Package Name: " . $packagename  .  PHP_EOL;

	#echo "Installing " . $packagename . " on " . $server ." " . $package;
	# execute shell script to install backend package

	echo "Installing " . $packagename . "-" . $version . ".tgz" . " on " . $tier ." " . $package . PHP_EOL;
	# execute shell script to install backend package
	#destination of the scp to send
	$sourcefile = "/home/jkm34/bundle/" . $packagename . "-" . $version . ".tgz";
	echo "FILEPATH: " . $sourcefile . PHP_EOL;
	
	$sourcefile = escapeshellarg($sourcefile);
#	$output = 
	       	exec("./scpdeploy.sh $sourcefile");


}
function doBundle ($type,$package,$server,$packagename,$version){
        echo "Bundle Request received" . PHP_EOL;
        echo "Type: " . $type . PHP_EOL;
        echo "Package From: " . $package . PHP_EOL;
        echo "Server: " . $server . PHP_EOL;
        echo "Package Name: " . $packagename . "-" . $version .  PHP_EOL;
	echo "SCP INITIATED... ";
	echo "TAR FILE RECEIVED!";


	echo "SCP INITIATED... ";
	echo "TAR FILE RECEIVED!";
	$mydb = new mysqli('192.168.1.12','root','password','deploy');
        if ($mydb->errno != 0){
                echo "Failed to connect to database: ".$mydb->error.PHP_EOL;
                exit(0);
        }
	$query = mysqli_query($mydb, "INSERT INTO Deploy VALUES('$packagename','$version')");


}
function requestProcessor($request)
{
  echo "received request".PHP_EOL;
  var_dump($request);
  if(!isset($request['type']))
  {
    return "ERROR: unsupported message type";
  }
  switch ($request['type'])
  {
    case "rollback":
      return doRollback($request['type'],$request['package'],$request['server'],$request['packagename'],$request['version'],$request['rollbackversion']);
    case "deploy":
      return doDeploy($request['type'],$request['package'],$request['server'],$request['packagename'],$request['version']);
    case "bundle":
      return doBundle($request['type'],$request['package'],$request['server'],$request['packagename'],$request['version']);
  }
  return array("returnCode" => '0', 'message'=>"Server received request and processed");
}
$server = new rabbitMQServer("deploy.ini","testServer");
echo "DeploySystem Server BEGIN".PHP_EOL;
$server->process_requests('requestProcessor');
echo "DeploySystem Server END".PHP_EOL;
exit();
?>
