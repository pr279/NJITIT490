#!/bin/bash

# SCP the tar from the deploy server to its destination



cd /home/jkm34/bundle

pv $1 | ssh alisha@192.168.1.27 'cat | tar xz -C /home/alisha/deploy'

#pv june-1.tgz | ssh alisha@192.168.1.28 'cat | tar xz -C /home/alisha/deploy'

